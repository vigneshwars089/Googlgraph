google.charts.load('current', {'packages':['gauge']});
google.charts.setOnLoadCallback(drawChart);

function drawChart() {

  // var data = google.visualization.arrayToDataTable([
  //   ["Label", "Value"],
  //   ["Memory", 80],
  //   ["CPU", 55],
  //   ["Network", 68]
  // ]);
  // console.log(data);

var data= null;

  $.getJSON("./ChartInput.json", function(jsonObj){
        console.log(jsonObj.GaugeData);
         data = google.visualization.arrayToDataTable(jsonObj['GaugeData']);
        console.log(data);

    //    var locations = jsonObj['points'];

      //  for (i = 0; i < locations.length; i++) {
      //  marker = new google.maps.Marker({
        //      position: new google.maps.LatLng(locations[i][1], locations[i][2]),
              // title: locations[]
          //    icon: {
            //          url: '/images_map/map_pin.png'
              //      },
            //  title: (locations[i][0]).toString(),
        //      map: map
        });

  var options = {
    width: 400, height: 120,
    redFrom: 90, redTo: 100,
    yellowFrom:75, yellowTo: 90,
    minorTicks: 5,
     animation: {duration: 1000, easing: 'inAndOut',}
  };

  var chart = new google.visualization.Gauge(document.getElementById('chart_div'));

  chart.draw(data, options);

  setInterval(function() {
    data.setValue(0, 1, 40 + Math.round(60 * Math.random()));
    chart.draw(data, options);
  }, 1300);
  setInterval(function() {
    data.setValue(1, 1, 40 + Math.round(60 * Math.random()));
    chart.draw(data, options);
  }, 1300);
  setInterval(function() {
    data.setValue(2, 1, 60 + Math.round(20 * Math.random()));
    chart.draw(data, options);
  }, 1300);
}

google.charts.load('current', {'packages':['geochart']});
     google.charts.setOnLoadCallback(drawRegionsMap);

     function drawRegionsMap() {

      var data= null;



       var options = {};

       var chart = new google.visualization.GeoChart(document.getElementById('regions_div'));

       $.getJSON("./ChartInput.json", function(jsonObj){
             console.log(jsonObj.GeoData);
          var data = google.visualization.arrayToDataTable(jsonObj['GeoData']);
            var data1 = google.visualization.arrayToDataTable(jsonObj['GeoData1']);
             console.log(data);
             var chart = new google.visualization.GeoChart(document.getElementById('regions_div'));


             chart.draw(data, options);
             setInterval(function() {
          //      data.setValue(3, 1, 160 + Math.round(20 * Math.random()));
                 chart.draw(data1, options);
              }, 5000);
              setInterval(function() {
           //      data.setValue(3, 1, 160 + Math.round(20 * Math.random()));
                  chart.draw(data, options);
               }, 2000);

         //    var locations = jsonObj['points'];

           //  for (i = 0; i < locations.length; i++) {
           //  marker = new google.maps.Marker({
             //      position: new google.maps.LatLng(locations[i][1], locations[i][2]),
                   // title: locations[]
               //    icon: {
                 //          url: '/images_map/map_pin.png'
                   //      },
                 //  title: (locations[i][0]).toString(),
             //      map: map
             });
      // chart.draw(data, options);
      //  setInterval(function() {
      //    data.setValue(0, 1, 140 + Math.round(60 * Math.random()));
      //    chart.draw(data, options);
      //  }, 1300);
      //  setInterval(function() {
      //    data.setValue(1, 1, 140 + Math.round(60 * Math.random()));
      //    chart.draw(data, options);
      //  }, 1300);
      //  setInterval(function() {
      //    data.setValue(2, 1, 160 + Math.round(20 * Math.random()));
      //    chart.draw(data, options);
      //  }, 1300);
      //  setInterval(function() {
      //    data.setValue(3, 1, 160 + Math.round(20 * Math.random()));
      //    chart.draw(data, options);
      //  }, 1300);
      //  setInterval(function() {
      //    data.setValue(4, 1, 160 + Math.round(20 * Math.random()));
      //    chart.draw(data, options);
      //  }, 1300);
      //  setInterval(function() {
      //    data.setValue(5, 1, 160 + Math.round(20 * Math.random()));
      //    chart.draw(data, options);
      //  }, 1300);
     }
